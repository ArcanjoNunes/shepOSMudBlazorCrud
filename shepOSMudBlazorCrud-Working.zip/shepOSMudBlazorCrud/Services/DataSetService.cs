﻿using System.Data;

namespace shepOSMudBlazorCrud.Services
{
    public class DataSetService
    {
        public string ReportPath { get; private set; } = default!;
        public string ReportTitle { get; set; } = default!;
        public string ReportFilename { get; set; } = default!;
        public string ReportDSSchema { get; set; } = default!;
        public DataSet ReportDataSet { get; set; } = new DataSet();

        public DataSetService()
        {
            SetReportsFolder();
            SetDataSet();
        }

        private void SetReportsFolder() => ReportPath = FindReportsFolder(Environment.CurrentDirectory);
        private void SetDataSet()
        {
            ReportDataSet.ReadXml(Path.Combine(ReportPath, "nwind.xml"));
            ReportDSSchema = "NorthWind"; 
        }

        private string FindReportsFolder(string startDir)
        {
            string directory = Path.Combine(startDir, "Reports");
            if (!Directory.Exists(directory))
                Directory.CreateDirectory(directory);
            return directory;
        }
    }
}
