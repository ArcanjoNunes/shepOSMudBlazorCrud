﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Reflection;

namespace shepOS
{
    public static class shepOSLibrary
    {
        public static string sAppWebPath = "";

        public static T? Clone<T>(this T source)
        {
            string serialized = JsonConvert.SerializeObject(source);
            return JsonConvert.DeserializeObject<T>(serialized);
        }

        public static T ToObject<T>(this IDictionary<string, object> dictSource) where T : class, new()
        {
            var oObject = new T();
            var oObjectType = oObject.GetType();

            foreach (KeyValuePair<string, object> oKeyPar in dictSource)
            {
                oObjectType.GetProperty(oKeyPar.Key)?.SetValue(oObject, oKeyPar.Value, null);
            }

            return oObject;
        }

        public static IDictionary<string, object?> AsDictionary(this object classSource, BindingFlags bindingAttr = BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.Instance)
        {
            return classSource.GetType().GetProperties(bindingAttr).ToDictionary
            (
                propInfo => propInfo.Name,
                propInfo => propInfo.GetValue(classSource, null)
            );
        }

        public static void ReloadEntity<TEntity>(this DbContext context, TEntity entity) where TEntity : class
        {
            context.Entry(entity).Reload();
        }
    }
}
