﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using shepOSMudBlazorCrud.Models;
using shepOSMudBlazorCrud.Services;
using Microsoft.EntityFrameworkCore;

namespace shepOSMudBlazorCrud.Repository
{
    public class shepOSDbContext : DbContext
    {
        public DbSet<Customer> Customers { get; set; }
        public DbSet<WeatherForecast> WeatherForecast { get; set; }

        public shepOSDbContext(DbContextOptions<shepOSDbContext> options) : base(options)
        {
        }
    }
}
