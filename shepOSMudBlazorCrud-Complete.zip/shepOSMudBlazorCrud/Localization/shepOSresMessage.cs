﻿namespace shepOSMudBlazorCrud.Localization
{
    public class shepOSresMessage
    {
    }
}
